

<div class="container">
    <br>
  <h2>Uploaded and deleted files list</h2>

  <div class="container text-right">
  <a href="<?php echo base_url(); ?>directories/lists"  class="btn btn-primary btn-lg ">Directory Files List</a>   
    <a href="<?php echo base_url(); ?>directories/add"  class="btn btn-primary btn-lg ">Upload file</a>   
    </div>     <br>
     
    <?php
            
            if ($this->session->flashdata('success_msg')) {
                echo '<div class="col-md-12 col-sm-6 msg"> <div class="panel panel-success">
                                    <div class="panel-heading">';
                echo $this->session->flashdata('success_msg');
                echo '</div> </div></div>';
            }
            if ($this->session->flashdata('error_msg')) {
                echo '<div class="col-md-12 col-sm-6 msg"> <div class="panel panel-danger">
                                    <div class="panel-heading">';
                echo $this->session->flashdata('error_msg');
                echo '</div> </div></div>';
            }
            ?>
<div class="col-md-12">   
  <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="2%">#</th>
                  <th width="25%">Name</th>
                  <th width="20%">Size</th>  
                  <th width="15%">Type</th>  
                  <th width="8%">Status</th>
                  <th width="20%">Action</th>
                </tr>
                </thead>
                <tbody>
              <?php $i = 1;
              if(!empty($list)){
              foreach($list as $data) {?>
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo $data['name'];?></td>
                  <td><?php echo $data['size'];?></td>
                  <td><?php echo $data['type'];?></td>
                  <td><?php if($data['is_deleted'] == 0) { echo 'Active';}  else { echo 'Deleted';} ?></td>
                  <td>                  
              <?php if($data['is_deleted'] == 0) {?> <a href="#" onClick="show_delete_confirm(<?php echo $data['id']; ?>,'<?php echo $data['name']; ?>')"  class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete </a> <?php } ?>
                  </td>
                </tr>
              <?php $i++; } } ?>
               
                </tbody>
                
              </table>
              </div>
</div>
<?php $this->load->view('directory/footer.php')?>
<script type="text/javascript">
    function show_delete_confirm(id,name)
    {
        var r = confirm("Are you sure you want to delete? ");
        if (r == true) {
            window.location = "<?php echo base_url(); ?>directories/delete/" + id+'/'+name;
        }
    }
</script>
<style>
.panel-success{
    background-color:#bbf1c7;
    padding: 15px;
}
.panel-danger{
    background-color:red;
    padding: 15px;
}
    </style>
