<div class="container py-3">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center">Add Directory</h2>
    
            <div class="row">
               
                <div class="col-md-8 offset-md-2">
                    <span class="anchor" id="formUserEdit"></span>
                    <hr class="my-2">

                    <!-- form user info -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">Directory Informations</h3>
                        </div>
                        <div class="card-body">
                            <form class="form" role="form" method="post" autocomplete="off" id="form1"  onSubmit="return validate();" action="<?= base_url()?>directories/save" enctype="multipart/form-data">

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label form-control-label">File Upload</label>
                                    <div class="col-lg-9">
                                        <input class="form-control InputBox" type="file"  name="file" id="file"  value="" required>
                                        <span id="file_error"></span>
                                    </div>
                                </div>
                                
                                
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label form-control-label"></label>
                                    <div class="col-lg-9">
                                        <input type="reset" class="btn btn-secondary" value="Cancel" id="cancel">
                                        <input type="submit" class="btn btn-primary" value="upload">
                                     
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /form user info -->

                </div>
            </div>
            <!--/row-->

        <br><br><br><br>

        </div>
        <!--/col-->
    </div>
    <!--/row-->
    
</div>
<!--/container-->   

<script>
$("#cancel").click(function(){
   $("form1").reset();
})

function validate() {
    var ext = $('#file').val().split('.').pop().toLowerCase();
	$("#file_error").html("");
	$(".InputBox").css("border-color","#F0F0F0");
	var file_size = $('#file')[0].files[0].size;
    if($.inArray(ext, ['gif','png','jpg','jpeg','txt','doc','docx','pdf']) == -1) {
       
        $(".InputBox").css("border-color","#FF0000");
        $("#file_error").html("Invalid format. Supported formats are txt,doc,docx,pdf,png,jpeg,jpg,gif");
        $("#file_error").css("color","red");
        return false;
    }
    else if(file_size>2097152) {
		$("#file_error").html("File size is greater than 2MB");
		$(".InputBox").css("border-color","#FF0000");
        $("#file_error").css("color","red");
		return false;
	} 

	return true;
}
</script>