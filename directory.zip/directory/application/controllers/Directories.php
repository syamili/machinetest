<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Directories extends CI_Controller {
	function __construct()
    {		
		parent::__construct();
		$this->load->model('dir_model');
	}
	public function index()
	{
		$this->load->view('directory/header');
		$data['list'] = $this->dir_model->view_all_records('directory');
		$this->load->view('directory/view',$data);
	}
	public function add()
	{
		$this->load->view('directory/header');
		$this->load->view('directory/add');
	}
	public function save(){
		// echo $this->input->post("filesize");
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|png|jpg|jpeg|txt|doc|docx|pdf|text';
		$config['max_size']	= '2048';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('file'))
		{
			$error = array('error' => $this->upload->display_errors());
			print_r($error) ;
			var_dump($_FILES);


		}
		else
		{
			$data1 = $this->upload->data();

			 $file = $data1['file_name'];
			 $filesize =  $data1['file_size'];
			 $filetype = $data1['file_type'];

			 $data = array(
                "name" => $file,
                "size" => $filesize,
                "type" => $filetype,
                "is_deleted" => 0
                );

			$result = $this->dir_model->insert('directory', $data);
			if ($result) {
                $this->session->set_flashdata('success_msg',
                    'File uploaded successfully. ');
                redirect('directories/');
            } else {
                 $this->session->set_flashdata('error_msg',
                    'File upload failed. ');
                     redirect('directories/');
            }
		}
	}
	


	public function delete($id,$name)
	{

		$data = array("is_deleted" => 1);
		$result = $this->dir_model->update('directory', $data, 'id', $id);
		if ($result) {
			unlink('uploads/'.$name);
				$this->session->set_flashdata('success_msg',
					'deleted successfully. ');
					redirect('directories/');
			} else {
				
				$this->session->set_flashdata('error_msg', 'Some error occured.Try Again ');
				redirect('directories/');
			}
	}
	public function delete_list($name){

		$data = array("is_deleted" => 1);
		$result = $this->dir_model->update('directory', $data, 'name', $name);
		if ($result) {
			unlink('uploads/'.$name);
				$this->session->set_flashdata('success_msg',
					'deleted successfully. ');
					redirect('directories/lists');
			} else {
				$this->session->set_flashdata('error_msg', 'Some error occured.Try Again ');
				redirect('directories/lists');
			}
	}

	public function lists(){
		$data['list'] = directory_map('./uploads/');
		$this->load->view('directory/header');
		$this->load->view('directory/lists',$data);
	}

}
