<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dir_model extends CI_Model
{
	
	public function __construct() { 	
        parent::__construct();
       
    }
    /**** function to get all active and non deleted records from table *****/
    public function view_all_active_records($table) {
        $this->db->select('*');
        $this->db->where('is_deleted', 0);
        $this->db->order_by("name", "asc");
        $this->db->from($table);
        $view = $this->db->get();
        if ($view->num_rows() > 0) {
            return $view->result_array();
        }
    }
    /**get all data***/
    public function view_all_records($table) {
        $this->db->select('*');
        $this->db->order_by("name", "asc");
        $this->db->from($table);
        $view = $this->db->get();
        if ($view->num_rows() > 0) {
            return $view->result_array();
        }
    }
   
    /**** function for insert data to the table *****/
    public function insert($table, $data) {        
        $query = $this->db->insert($table, $data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

     /*** check code exists or not ***/
     public function check_code($table,$code){
        $this->db->select('*');
        $this->db->where('is_deleted', 0);
        $this->db->where('code', $code);
        $this->db->from($table);
        $view = $this->db->get();
        return $view->num_rows();
    }

    /*** common edit ***/
    function edit($table, $field, $id)
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $result = $this->db->get();
        if ($result->num_rows() > 0) {
            return $result->row_array();
        }
    }

    /****fetch_single_row***/

    function fetch_single_row($table,$field,$value){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $value);
        $result = $this->db->get();
        if ($result->num_rows() > 0) {
            return $result->row_array();
        }
    }
    

	 /****Update table****/
    function update($table, $data, $field, $id)
    {
        $this->db->where($field, $id);
        $result = $this->db->update($table, $data);
        return $result;
    }

 

}
